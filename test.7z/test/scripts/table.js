
	Vue.component('common-table',{
		template:'<div class="table-wrapper">\
        <div class="select-list" v-show="selectListSeen">\
        	<div class="select-item" :style="{height:(maxThNum+1)*14+5+\'px\'}" @click="selectStock(0)">\
        		<span class = "checkbox"></span>\
        	</div>\
            <div class="select-item" v-for="(item,index) in rowArr" :style="basicStyleText" @click="selectStock(index+1)">\
                <span class = "checkbox"></span>\
            </div>\
        </div>\
        <div id="fixed-table" v-show="fixedTableSeen">\
        	<div class="select-list" v-show="selectListSeen">\
	        	<div class="select-item" :style="{height:(maxThNum+1)*14+5+\'px\'}" @click="selectStock(0)">\
	        		<span class = "checkbox"></span>\
	        	</div>\
	        </div>\
	        <table  class="left-table" :style ="{width:leftTableWidth+\'px\'}">\
	            <tr>\
	                <th v-for="item in thLists" v-if="item.fixed === \'left\'" :colspan="item.title_children.length" :style="item.style"><dl v-if="item.title_children.length!==0">\
	                        <dt>\
	                            {{item.title}}\
	                        </dt>\
	                        <dd v-for="child in item.title_children" :style="{width:parseFloat((1/item.title_children.length)*100)+\'%\'}" >\
	                            {{child.title}}\
	                            <span class="prompt np" v-if="item.pop&&item.popText" @click.prevent="showTip(item.popText)">?</span>\
	                        </dd>\
	                    </dl>\
	                    <span v-else v-for="value in item.title">\
	                        {{value}}<br/>\
	                        <span class="prompt" v-if="item.pop&&item.popText" @click.prevent="showTip(item.popText)">?</span>\
	                    </span>\
	                </th>\
	            </tr>\
	        </table>\
	        <div class="right-wrapper" style="overflow-x:hidden">\
	            <table class="right-table right-fixed" style="overflow-x:hidden" :style ="{width:rightTableWidth+\'px\'}">\
	                <tr>\
	                    <th v-for="item in thLists" v-if="item.fixed === \'\'" :colspan="item.title_children.length" :style="item.style">\
	                        <dl v-if="item.title_children.length!==0">\
	                            <dt v-for="titleValue in item.title">\
	                                {{titleValue}}\
	                                <span class="prompt np" v-if="item.pop&&item.popText" @click.prevent="showTip(item.popText)">?</span>\
	                            </dt>\
	                            <dd v-for="child in item.title_children" :style="{width:parseInt((1/item.title_children.length)*100)+\'%\'}" @click="sortByKey($event,child.data_index)">\
	                                <b  v-for="(value,index) in child.title">\
	                                    {{value}}\
	                                    <span></span>\
	                                </b>\
	                            </dd>\
	                        </dl>\
	                        <b v-for="(value,point) in item.title" v-else @click="sortByKey($event,item.data_index,point)">\
	                            {{value}}<span></span><br/><span v-if="item.title<=1" class="prompt" @click.prevent="showTip(item.popText)">?</span>\
	                        </b>\
	                        <span v-if="item.title>1" class="prompt" @click="showTip(item.popText)">?</span>\
	                    </th>\
	                </tr>\
	            </table>\
	        </div>\
        </div>\
        <div id="wrap" style="margin-bottom:1rem">\
	        <table  class="left-table" :style ="{width:leftTableWidth+\'px\'}">\
	            <tr>\
	                <th v-for="item in thLists" v-if="item.fixed === \'left\'" :colspan="item.title_children.length" :style="item.style"><dl v-if="item.title_children.length!==0">\
	                        <dt>\
	                            {{item.title}}\
	                        </dt>\
	                        <dd v-for="child in item.title_children" :style="{width:parseInt((1/item.title_children.length)*100)+\'%\'}" >\
	                            {{child.title}}\
	                            <span class="prompt np" v-if="item.pop&&item.popText" @click.prevent="showTip(item.popText)">?</span>\
	                        </dd>\
	                    </dl>\
	                    <span v-else v-for="value in item.title">\
	                        {{value}}<br/>\
	                        <span class="prompt" v-if="item.pop&&item.popText" @click.prevent="showTip(item.popText)">?</span>\
	                    </span>\
	                </th>\
	            </tr>\
	            <tr v-for="(item,index) in rowArr" @click="trClick(index)">\
	                <td v-for="obj in leftTableKeys" v-if="obj.key.length>1" :style="basicStyleText" @click="tdClick($event,obj)">\
	                    <span v-for="value in obj.key" class="stock">\
	                        {{item[value].value}}\
	                        <br/>\
	                    </span>\
	                </td>\
	            </tr>\
	        </table>\
	        <div class="right-wrapper" @touchmove= "isBorder" @scroll = "fixedMove">\
	            <table class="right-table" :style ="{width:rightTableWidth+\'px\'}">\
	                <tr>\
	                    <th v-for="item in thLists" v-if="item.fixed === \'\'" :colspan="item.title_children.length" :style="item.style">\
	                        <dl v-if="item.title_children.length!==0">\
	                            <dt v-for="titleValue in item.title">\
	                                {{titleValue}}\
	                                <span class="prompt np" v-if="item.pop&&item.popText" @click.prevent="showTip(item.popText)">?</span>\
	                            </dt>\
	                            <dd v-for="child in item.title_children":style="{width:ddComputedWidth(child.title[0])+\'px\'}" @click="sortByKey($event,child.data_index)">\
	                                <b  v-for="(value,index) in child.title">\
	                                    {{value}}\
	                                    <span></span>\
	                                </b>\
	                            </dd>\
	                        </dl>\
	                        <b v-for="(value,point) in item.title" v-else @click="sortByKey($event,item.data_index,point,item.title)">\
	                            {{value}}<span v-if="point>=1||item.title.length==1"></span><span v-if="item.isPop&&point==0" class="prompt" @click.prevent="showTip(item.popText)">?</span><br/>\
	                        </b>\
	                    </th>\
	                </tr>\
	                <tr v-for="(item,index) in rowArr" @click="trClick(index)">\
	                    <td v-for="obj in rightTableKeys" :style="basicStyleText"  v-if="obj.key.length>1">\
	                        <span v-for="value in obj.key" :style="item[value].style">\
	                            {{item[value].value}}\
	                        	<br/>\
	                        </span>\
	                    </td>\
	                    <td v-else :style="basicStyleText+item[obj.key[0]].style" @click="tdClick($event,obj,item)">\
	                        {{item[obj.key[0]].value}}\
	                    </td>\
	                </tr>\
	            </table>\
	        </div>\
        </div>\
        <div class="clr"></div>\
	</div>',
	props:['configData','isSort'],
	data:function(){
		return{ 
			totalWidth:0,
			maxThNum:1,
			maxTdNum:1,
			selectListSeen:false,
			fixedTableSeen:false,
			page:1,
			beforeScrollTop:document.body.scrollTop,
		}
	},
	computed:{
			thLists:function(){
				return this.configData.config.columns;
			},
			rowData:function(){
				return this.configData.data;
			},
			keyTables:function(){
				var leftArr = [],
					rightArr = [],
					allKey = [],
					leftTableWidth = [0],
					rightTableWidth = [0],
					reg = new RegExp(/\[.*\](\*|\+|\/|\-)\[.*\]/),
					isFixedWidth = this.thLists.length===3?true:false;
				for(x in this.thLists){
					var temp = this.thLists[x],
						flag = temp.fixed ==='left',
						keyList = flag?leftArr:rightArr,
						totalWidth = 0,
						tableWidth = temp.fixed === 'left'?leftTableWidth:rightTableWidth,
						thWidth = 0;
					if(isFixedWidth)temp.width = document.body.offsetWidth/3;
					if(temp['title'].length>1){
						this.maxThNum = 2;
					}
					for(k in temp['title']){
						reg.test(temp['title'][k])?temp.width = 120:'';
					}
					if(temp['title_children'].length!==0){
						var temp = temp['title_children'];
						this.maxThNum = 2;
						for(var y in temp){
							tableWidth[0]+=temp[y].width;
		                	var obj = {};
		                    temp2 = temp[y];
		                    var res= temp2['data_index'],
		                        styleText = 'width:'+temp['width']+'px';
		                    Array.prototype.push.apply(allKey,res);
		                    for(i in res){
		                    	var config = this.configData.config.xuangu_column[res[i]].index_meta;
		                    	if(!Array.isArray(config)&&config.description.desc){
		                    		this.thLists[x].isPop = true;
		                    		this.thLists[x].popText = config.description.desc;
		                    		thWidth = this.computedWidth(this.thLists[x],true); 
		                    	}else{
		                    		thWidth = this.computedWidth(this.thLists[x]);
		                    	}
		                    }
		                    this.maxTdNum = temp2['data_index'].length>this.maxTdNum?temp2['data_index'].length:this.maxTdNum;
		                    keyList.push({key:res,style:styleText});
		                }
					}else{
						tableWidth[0] +=temp.width;
						var res = temp['data_index'],
		                    styleText = 'width:'+temp['width']+'px';
		                Array.prototype.push.apply(allKey,res);
	                	for(i in res){
	                    	var config = this.configData.config.xuangu_column[res[i]].index_meta;
	                    	if(!Array.isArray(config)&&config.description.desc){
	                    		this.thLists[x].isPop = true;
	                    		this.thLists[x].popText = config.description.desc;
	                    		thWidth = this.computedWidth(this.thLists[x],true);
	                    	}else{
	                    		thWidth = this.computedWidth(this.thLists[x]);
	                    	}
	                    }
		                this.maxTdNum = temp['data_index'].length>this.maxTdNum?temp['data_index'].length:this.maxTdNum;
		                keyList.push({key:res,style:styleText})
					}
					this.thLists[x].style ='width:'+thWidth+'px;'+'height:'+((this.maxTdNum+1)*14+5)+'px;';
				}
				return {
					left:leftArr,
					right:rightArr,
					allKey:allKey,
					leftTableWidth:leftTableWidth[0],
					rightTableWidth:rightTableWidth[0]
				}
			},
			leftTableKeys:function(){
				return this.keyTables.left;
			},
			rightTableKeys:function(){
				return this.keyTables.right;
			},
			leftTableWidth:function(){
				return this.keyTables.leftTableWidth;
			},
			rightTableWidth:function(){
				return this.keyTables.rightTableWidth;
			},
			allKeyList:function(){
				return this.keyTables.allKey;
			},
			basicStyleText:function(){
				return 'height:'+((this.maxTdNum+1)*16+5)+'px;';
			},
			rowArr:function(){
				return this.rorArrComputed();
			},
		},
		created:function(){
			var self =this;
			bus.$on('addSelfStocks',function(bool){
				self.selectListSeen = bool;
			})
		},
		mounted:function(){
			$('#wrap').pullScroll({
				el:'.right-wrapper',
				downPullEnable:false,
				upPullEnable:true,
				upPullEvent:function(){

				}
			})
			if($('body').height() >= $(window).height()){
				$(window).on('scroll',this.tableMove);
			}
			//$(window).on('scroll',this.tableMove);
			var self = this;
			$('#wrap').pullScroll({
				el:'.left-table',
				downPullEnable:false,
				upPullEnable:true,
				upPullEvent:function(){
					self.$emit('nextPage',++self.page);
				}
			})
		},
		methods:{
			tdComputedWidth:function(obj){
				var key = obj.key[0];
				for(x in thLists){
					if(key.title_children.length>1){
						var reg = new RegExp(/[0-9]*\.[0-9]*\.[0-9]*\-[0-9]*\.[0-9]*\.[0-9]*/);
						for(y in title_children){
							if(title_children[y].data_index[0]===key){
								if(reg.test(title_children[y].title[0])){
									return 240;
								}else{
									return 120;
								}
							}
						}
					}else{
						return false;
					}
				}
			},
			ddComputedWidth:function(str){
				var reg = new RegExp(/[0-9]*\.[0-9]*\.[0-9]*\-[0-9]*\.[0-9]*\.[0-9]*/);
				return reg.test(str)?240:120;
			},
			tableMove:function(){
				var afterScrollTop = document.body.scrollTop,
					delta = afterScrollTop - this.beforeScrollTop;
				if(delta>=0){
					if(vue.isMainContentShow && getAppVersion()){
						bus.$emit('hideBottom',false)
					}
				}else{
					if(vue.isMainContentShow && getAppVersion()){
						bus.$emit('hideBottom',true)
					}
				}
				this.beforeScrollTop = afterScrollTop;
				var top = $(window).scrollTop();
				if(top>$('header').height() + $('.concept-con').height() + $('#closeMeaning').height() + $('#browserBanner').height()){
					this.fixedTableSeen = true;
					setTimeout(function(){
						$('.right-fixed').offset({
							left:$('.right-table').eq(1).offset().left-$('.left-table').width()-$('.select-item').width()
						})
					},10);
				}else{
					this.fixedTableSeen = false;
					$('.left-table').removeClass('left-border');
				}
			},
			fixedMove:function(){
				$('.right-fixed').offset({
					left:$('.right-table').eq(1).offset().left-$('.left-table').width()-$('.select-item').width()
				})
			},
			trClick:function(index){
				if(this.selectListSeen){
					this.selectStock(index+1);
					return false;
				}
				var stockcode = $('.left-table tr').eq(index+2).children('td').children('span').eq(1).text().trim();
				var markid = this.configData.data[index]['股票代码'].split('.')[1];
				if(!getAppVersion()){
					switch(markid){
						case 'SZ':location.href = '//m.10jqka.com.cn/stockpage/33_'+stockcode+'/#refCountId=R_55c0c070_428&atab=geguNews';break;
						case 'SH':location.href = '//m.10jqka.com.cn/stockpage/17_'+stockcode+'/#refCountId=R_55c0c070_428&atab=geguNews';break;
						//基金跳转地址
						case 'OF':break;
						default:break;
					}
				}else{
					if(markid === 'OF'){
						return false;
					}
					location.href = 'client.html?action=ymtz^stockcode='+stockcode+'^webid=2205^mode=new';
					index = index + 1;
					hxmJumpNativeStat('free_iwencai_result_xuangu.stock.'+index,2205,{
						'to_scode':stockcode,
						'url_ver':'JGY-2'
					})
				}
			},	
			tdClick:function(event,obj,item){
				var dom  =event.target;
				var statid = 'free_iwencai_result_xuangu';
				var norm = obj.key[0];
				var index = $(dom).parent('tr').index();
				if($(dom).text().trim()==='点击查看'||$(dom).css('color')==='rgb(28, 118, 236)'){
					hxmJumpPageStat(statid,'free_iwencai_result_zhengu');
					var stockcode = $('.left-table tr').eq(index+1).children('td').children('span').eq(1).text().trim();

					//客户端协议跳转--点击查看
					var nowurl = window.location.href;
			        var lastIndex = nowurl.lastIndexOf('/');
			        nowurl = nowurl.substring(0, lastIndex+1);
					if( getAppVersion() ){
						var jumpUrl = nowurl + 'null.html?q=' +stockcode+' '+norm;
						location.href = 'client.html?action=ymtz^url=' + jumpUrl + '^webid=2804^mode=new';
					}
					else{
						window.location.href = nowurl + 'wapRet.html?q=' +encodeURIComponent(stockcode+' '+norm) + '&showAd=' + getParam('showAd');
					}

					event.stopPropagation();
				}else if(item[norm].isLongString){
					hxmJumpPageStat(statid+'.longstr');
					bus.$emit('showDetailDialog',$(dom).text());
					event.stopPropagation();
				}
			},
			isBorder:function(){
				var show = $('.right-table').offset().left >= $('.left-table').width();
				show?$('.left-table').removeClass('left-border'):$('.left-table').addClass('left-border');
			},
			computedWidth:function(arr,bool){
				var dom = '',
				 	extendWidth = bool?59:46;
				if(arr.title_children.length==0){
					for(y in arr.title){
						dom+='<b>'+arr.title[y]+'</b><br/>';
					}
				}else{
					var reg = new RegExp(/[0-9]*\.[0-9]*\.[0-9]*\-[0-9]*\.[0-9]*\.[0-9]*/),
						totalWidth = 0; 
					for(y in arr.title_children){
						if(reg.test(arr.title_children[y].title[0])){
							totalWidth+=240
						}else{
							totalWidth+=120
						}
					}
					return arr.width>totalWidth?arr.width:totalWidth;
					/*dom +='<dl><dt>';
					for(y in arr.title){
						dom+=arr.title[y]+'<br/>'
					}
					dom +='</dt>';
					for(y in arr.title_children){
						dom += '<dd style="float:left;width:100px !important;">'+arr.title_children[y].title[0]+'</dd>';
					}
					dom += '</dl>'*/
				}
				var wrapper = $('<div/>',{
					style:'position:absolute;top:0;left:0;display:inline-block;height:0px;overflow:hidden;font-size:14px;visibility:hidden;'
				}).appendTo($('body')),
				   width = $(wrapper).append(dom).width()+extendWidth;
				return arr.width>width?arr.width:width;
			},
			sortByKey:function(event,key,point,title){
				if((!this.isSort&&title!==undefined&&title.length>1)||(point<1&&title!==undefined&&title.length!==1)){
					return false;
				}
				if(event.srcElement.tagName === 'DD')return false;
				if(event.srcElement.tagName==='SPAN'){
					var dom = $(event.target);
				}else{
					if($(event.target).children('span').eq(0).length===0||$(event.target).children('span').eq(0).hasClass('prompt')){
						var dom = $(event.target).next().children('span').eq(0);
					}else{
						var dom = $(event.target).children('span').eq(0);
					}
				}
				var self = this;
				this.$emit('sortByKey',key,dom);
			},
			//展示Key描述
			showTip:function(text){
				bus.$emit('showDetailDialog',text);
			},
			selectStock:function(index){
				var statid = 'free_iwencai_result_zhengu';
				var dom = document.getElementsByClassName('checkbox'),
				    style = dom[index].style;
				if(index ===0){
					hxmClickStat(statid+'.addzx.all');
					if(style.backgroundImage !=''){
						var styleText = '',
							borderText = '1px solid #666666';
						bus.$emit('canAddOptional',false);
					}
					else{
						var styleText = 'url(./images/check.png)',
							borderText = 'none';
						bus.$emit('canAddOptional',true);
					}
					for(var i=0;i<dom.length;i++){
						dom[i].style.backgroundImage = styleText;
						dom[i].style.border = borderText;
					}
				}else{
					if(style.backgroundImage !=''){
						style.backgroundImage = '';
						style.border = '1px solid #666666';
					}else{
						style.backgroundImage = 'url(./images/check.png)';
						style.border = 'none';
					}
					dom[index].style.backgroundImage = style.backgroundImage;
					dom[index].style.border = style.border;
					var stockcode = document.getElementsByClassName('stock')[2*index-1].textContent.trim();
					bus.$emit('canAddOptional',stockcode);
				}
			},
			//判断配置字段是否有效
			isEmptyObject:function(obj){
				return false;
			},
			//行数组计算
			rorArrComputed:function(){
				var rowArr = new Array(this.rowData.length);
				for(j in this.rowData){
					var obj = {};
					for(i in this.allKeyList){
						var key = this.allKeyList[i];
						obj[key] = {},
						value = this.rowData[j][key],
						flag = this.configData.config.xuangu_column[key].display_config.detail_pop === undefined;
						if((value === undefined||value=== null||value === 'null')&&flag){
							obj[key].value = '--';
							obj[key].style = this.nullStyle(key);
						}else{
							if(key==='股票代码'){
								value = value.split('.')[0];
							}
							obj[key] = this.deployStyle(key,value);
						}
					}
					rowArr[j] = obj;
				}
				return rowArr;
			},
			//空类型规则配置
			nullStyle:function(key){
				var styleText = this.alignStyle(key),
					configData = this.configData.config.xuangu_column[key].display_config;
				if(configData.link!==undefined&&configData.link.length!==0){
					styleText +='color:#1C76EC;';
				}
				return styleText;
			},
			//非空类型规则配置
			deployStyle:function(key,value){
				var styleText = this.alignStyle(key),
					configData = this.configData.config.xuangu_column[key].display_config,
					type = this.configData.config.xuangu_column[key].type,
					isLongString = configData.long_string !==undefined&&configData.long_string !==null&&configData.long_string!=='';
					obj = {
						value:value,
						style:styleText
					}
				for(x in configData){
					if(!this.isEmptyObject(configData[x])){
						switch(x){
							case 'detail_pop':
								obj.value = obj.value===null||obj.value===undefined?'点击查看':obj.value;
								obj.style +='color:#1C76EC;';break;
							case 'hl':
								for(y in configData[x]){
									if(this.isMeetCondition(configData[x][y],value)){
										configData[x][y].effect==='red'?obj.style += 'color:#FF0000;':obj.style += 'color:#008000;';
									}
								}break;
							case 'logic_replace':
								for(y in configData[x]){
									this.isMeetCondition(configData[x][y],value)?obj.value = configData[x][y].effect:'';
								}break;
						}
					}
				}
				if(type==='DOUBLE'&&!isNaN(parseInt(value))){
					if(typeof value ==='string')value = Number(value);
					obj.value = this.deployUnit(value);
				}
				type==='STR'?obj.isLongString = true:'';
				return obj;
			},
			//逻辑判断
			isMeetCondition:function(config,value){
				var relation  =config.comp_relation,
					symbol = config.comp_with,
					effect = config.effect;
				switch(relation){
					case 'include':
						if(value.indexOf(symbol)>-1){
							return true;
						}break;
					case 'any':return true;break;
					case '=':return value==symbol;break;
					case '>=':
					case '<=':
					case '<':
					case '>':
						if(typeof value ==='string'){
							value = new Number(value);
						}
						return eval(value+relation+symbol);break;
					default:return false;break;
				}
			},
			//判断数字是否是整数
			isInterger:function(num){
				return Math.floor(num)===num;
			},
			toThousands:function(num) {
				var temp =num;  
			    var num = (parseFloat(Math.abs(num)).toFixed(2) || 0).toString(), result = '';  
				var left = num.split('.')[0];//整数部分
				var right = num.split('.')[1]?'.'+num.split('.')[1]:''//小数部分
			    while (left.length > 3) {
			        result = ',' + left.slice(-3) + result;  
			        left = left.slice(0, left.length - 3); 
			    }
			    if (left) { result = left + result + right; }
			    return temp>=0?result:'-'+result;
			}, 
			//单位与精度配置
			deployUnit:function(value){
				return Math.abs(value)>100000000?(this.toThousands(parseFloat(value/100000000).toFixed(2)))+'亿':Math.abs(value)>10000?this.toThousands(parseFloat(value/10000).toFixed(2))+'万':this.isInterger(value)&&(value+'').split('.')[1]!==undefined&&(value+'').split('.')[1].length>2?this.toThousands(parseFloat(value).toFixed(2)):this.toThousands(parseFloat(value).toFixed(2));
			},
			//对齐方式规则配置
			alignStyle:function(key){
				var configData = this.configData.config.xuangu_column[key],
					styleText = '';
				switch(configData.type){
					case 'STR':styleText = 'text-align:center;';break;
					case 'DOUBLE':
					case 'LONG':styleText = 'text-align:right;';break;
					case 'DATE':
					default:styleText = 'text-align:center;';break;
				}
				return styleText;
			}
			//
		}
	})
